public enum ActivityType {
    WEIGHT, CARDIO, YOGA, SWIMMING;
}
