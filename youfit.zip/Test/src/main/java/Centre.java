import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Centre {
    List<Slots> slotsList;

    long id;
    String centreName;
    List<Activity> activities;

    public Centre(List<Slots> slotsList, long id, String centreName) {
        this.slotsList = slotsList;
        this.id = id;
        this.centreName = centreName;
    }

    public Centre(long id) {
        this.id = id;
    }

    public List<Slots> getSlotsList() {
        return slotsList;
    }

    public void setSlotsList(List<Slots> slotsList) {
        this.slotsList = slotsList;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCentreName() {
        return centreName;
    }

    public void setCentreName(String centreName) {
        this.centreName = centreName;
    }

    public List<Activity> getActivities() {
        return activities;
    }

    public void setActivities(List<Activity> activities) {
        this.activities = activities;
    }

    public void bookSlot(int id, User user, Slots slots, Activity activity) {
       slots.occupiedSlots.put(user, activity);
    }

    public void removeSlot(int id, Slots slots) {
        slots.activitiesList.remove(id);
    }
}
