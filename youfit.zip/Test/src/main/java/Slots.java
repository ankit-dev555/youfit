import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Slots {
    long from;
    long to;
    long id;
    List<Activity> activitiesList;
    Map<User, Activity> occupiedSlots;

    public Slots(long from, long to, long id) {
        this.from = from;
        this.to = to;
        this.id = id;
        this.activitiesList = new ArrayList<>();
        this.occupiedSlots = new HashMap<>();
    }

    public long getFrom() {
        return from;
    }

    public void setFrom(long from) {
        this.from = from;
    }

    public long getTo() {
        return to;
    }

    public void setTo(long to) {
        this.to = to;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public List<Activity> getActivitiesList() {
        return activitiesList;
    }

    public void setActivitiesList(List<Activity> activitiesList) {
        this.activitiesList = activitiesList;
    }

    public Map<User, Activity> getOccupiedSlots() {
        return occupiedSlots;
    }

    public void setOccupiedSlots(Map<User, Activity> occupiedSlots) {
        this.occupiedSlots = occupiedSlots;
    }
}
