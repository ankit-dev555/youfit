import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Driver {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        WorkoutService workoutService = WorkoutService.getWorkOutServiceInstance();
        workoutService.addCentre("Kormangla");
        workoutService.addCentre("Bellandur");
        List<Slots> slotsList = new ArrayList<>();
        Slots slots1 = new Slots(6, 9, 1);
        Slots slots2 = new Slots(18, 21, 2);
        slotsList.add(slots1);
        slotsList.add(slots2);
        workoutService.addCentreTimings("Kormangla", slotsList);


        List<Slots> slotsList1 = new ArrayList<>();
        Slots slots4 = new Slots(7, 10, 3);
        Slots slots3 = new Slots(21, 22, 4);
        slotsList1.add(slots3);
        slotsList1.add(slots4);
        workoutService.addCentreTimings("Bellandur", slotsList1);
        List<Activity> activities = new ArrayList<>();
        activities.add(new Activity(ActivityType.WEIGHT));
        workoutService.addActivities("Kormangla" , activities);

        workoutService.addSlots("Kormangla", ActivityType.WEIGHT, 6, 7, 100);

        Map<String, List<Slots>> map = (workoutService.viewWorkOut(ActivityType.WEIGHT));
        for (Map.Entry<String, List<Slots>> entry:
             map.entrySet()) {
            if(entry.getValue().size()>0)
            for (Slots slots:
                 entry.getValue()) {
                System.out.println(entry.getKey() + " " + ActivityType.WEIGHT + " " + slots.getFrom() + " " + slots.getTo());
            }
        }

        User user = new User("Saurabh");

        System.out.println(workoutService.bookSlot(user, "Kormangla", 6, 7, ActivityType.WEIGHT));

        map = (workoutService.viewWorkOut(ActivityType.WEIGHT));
        for (Map.Entry<String, List<Slots>> entry:
                map.entrySet()) {
            if(entry.getValue().size()>0)
                for (Slots slots:
                        entry.getValue()) {
                    System.out.println(entry.getKey() + " " + ActivityType.WEIGHT + " " + slots.getFrom() + " " + slots.getTo());
                }
        }

    }
}
