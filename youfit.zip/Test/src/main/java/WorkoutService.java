import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WorkoutService {
    private static WorkoutService workoutService;
    private static long id = 0;

    private Map<String, Centre> idVsCentre;

    private WorkoutService() {
        idVsCentre = new HashMap<>();
    }

    public static WorkoutService getWorkOutServiceInstance() {
        if(workoutService == null) {

            workoutService = new WorkoutService();
        }
        return workoutService;
    }

    public Centre addCentre(String name) {
        Centre centre = new Centre(id);
        idVsCentre.put(name, centre);
        return centre;
    }

    public void addCentreTimings(String name, List<Slots> slots) {
        Centre centre = idVsCentre.get(name);
        centre.setSlotsList(slots);
    }

    public void addActivities(String name, List<Activity> activities) {
        Centre centre = idVsCentre.get(name);
        centre.setActivities(activities);
    }

    public boolean addSlots(String name, ActivityType activityType, long start, long end, int slots) {
        Centre centre = idVsCentre.get(name);
        List<Slots> slotsList = new ArrayList<>();
        List<Slots> availableSlots = centre.getSlotsList();
        for(int i=0;i<slots;i++) {
            for(Slots slots1: availableSlots) {
                if(slots1.getFrom() <= start && slots1.getTo() >= end) {
                    List<Activity> activities = slots1.activitiesList;
                    activities.add(new Activity(activityType));
                }
            }
        }
        return false;
    }

    public Map<String, List<Slots>> viewWorkOut(ActivityType activity) {
        Map<String, List<Slots>> map = new HashMap<>();
        for(Map.Entry<String, Centre> entry: idVsCentre.entrySet()) {
            List<Slots> slots = entry.getValue().slotsList;
            if(!map.containsKey(entry.getKey())) {
                map.put(entry.getKey(), new ArrayList<>());
            }
            for(Slots slots1: slots) {
                for(Activity activity1: slots1.getActivitiesList()) {
                    if(activity1.getActivityType() == activity) {
                        map.get(entry.getKey()).add(slots1);
                    }
                }
            }
        }
        return map;
    }

    public boolean bookSlot(User user, String centre, long from, long to, ActivityType activityType) {
        Centre centre1 = idVsCentre.get(centre);
        List<Slots> slots = centre1.getSlotsList();
        int id = 0;
        for(Slots slots1: slots) {
            if(slots1.getFrom()<=from && slots1.getTo()>=to) {

                boolean isActivityPresent = false;

                int id1 = 0;
                int tmp = -1;
                for(Activity activity: slots1.getActivitiesList()) {

                    if(activity.getActivityType() == activityType) {
                        isActivityPresent = true;
                        tmp = id1;
                        centre1.bookSlot(id1, user, slots1, activity);
                    }
                    id1+=1;
                }
                if(isActivityPresent) {
                    centre1.removeSlot(tmp, slots1);
                    return true;
                }
            }
            id += 1;
        }
        return false;
    }

}
